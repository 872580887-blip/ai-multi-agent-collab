# 🚀 快速开始指南

## 📋 前置要求

### 必需软件
- **Node.js** >= 16.0.0
- **fswatch**（macOS 文件监听工具）
- **macOS** 系统（RPA 通知器需要）

### 安装 fswatch
```bash
brew install fswatch  # 文件监听（必需）
```

---

## 🎯 三步启动

### 步骤 1：进入项目目录
```bash
cd /Users/mac/Desktop/是/ai-multi-agent-collab/
```

### 步骤 2：启动桥接服务器（WebSocket）
```bash
node src/bridge-server.js &
```

**预期输出**：
```
╔════════════════════════════════════════╗
║   🦞 Kiro ↔ OpenClaw 桥接服务          ║
╠════════════════════════════════════════╣
║   浏览器: http://localhost:8767       ║
║   Kiro API: http://localhost:8767/api/kiro/send
╚════════════════════════════════════════╝
```

### 步骤 3：启动 RPA 通知器（自动唤醒 IDE）
```bash
node src/rpa-notifier.js &
```

**预期输出**：
```
[2026-02-02T12:00:00.000Z] 🚀 Kiro RPA 通知器启动中...
```

---

## 🌐 打开浏览器

访问：`http://localhost:8767`

你会看到三方聊天界面，可以：
- 发送消息给 OpenClaw
- 查看 OpenClaw 的回复
- 控制是否通知 Kiro IDE

---

## ✅ 验证系统运行

### 测试 1：浏览器 → OpenClaw
1. 在浏览器输入："你好"
2. 等待 OpenClaw 回复
3. 应该看到实时流式回复

### 测试 2：OpenClaw → Kiro IDE
1. OpenClaw 回复后
2. Kiro IDE 应该自动弹出通知
3. 格式：`📬 新消息来自【openclaw】：你好...`

### 测试 3：Kiro → OpenClaw
在 Kiro IDE 中执行：
```bash
curl -X POST http://localhost:8767/api/kiro/send \
  -H 'Content-Type: application/json' \
  -d '{"message":"测试消息"}'
```

应该在浏览器看到 Kiro 的消息。

---

## 🛠️ 常见问题

### Q1：fswatch 未找到
**错误**：`fswatch: command not found`

**解决**：
```bash
brew install fswatch
```

### Q2：端口 8767 被占用
**错误**：`Error: listen EADDRINUSE: address already in use :::8767`

**解决**：
```bash
# 查找占用端口的进程
lsof -i :8767

# 杀死进程
kill -9 <PID>
```

### Q3：RPA 通知器无法激活 IDE
**原因**：Terminal 没有辅助功能权限

**解决**：
1. 打开"系统设置" → "隐私与安全性" → "辅助功能"
2. 添加"终端"或"iTerm"
3. 重启 RPA 通知器

### Q4：消息没有通知到 Kiro
**检查**：
```bash
# 查看消息队列目录
ls -la .kiro-chat-messages/

# 查看 RPA 通知器日志
cat kiro-notifier.log
```

---

## 🔧 高级配置

### 修改端口
编辑 `src/bridge-server.js` 最后一行：
```javascript
const PORT = 8767;  // 改成你想要的端口
```

### 修改通知格式
编辑 `src/rpa-notifier.js` 第 26 行：
```javascript
const formatted = `📬 新消息来自【${sender}】：${message}`;
// 改成你想要的格式
```

### 禁用自动通知
在浏览器界面点击"通知 Kiro"开关，关闭即可。

---

## 📊 系统状态检查

### 检查服务状态
```bash
# 查看进程
ps aux | grep "bridge-server\|rpa-notifier"

# 查看端口
lsof -i :8767

# 查看日志
tail -f kiro-notifier.log
```

### API 健康检查
```bash
curl http://localhost:8767/api/status
```

**预期输出**：
```json
{
  "clients": 1,
  "kiro": true,
  "openclaw": true
}
```

---

## 🎉 成功！

如果所有测试都通过，恭喜你！系统已经完全运行。

**下一步**：
- 阅读 [架构文档](./architecture.md) 了解系统原理
- 查看 [痛点分析](./pain-points.md) 了解我们解决的问题
- 尝试 [自定义 Agent](../examples/custom-agent.js) 接入你自己的 AI

---

**遇到问题？** 提交 [GitHub Issue](https://github.com/your-repo/ai-multi-agent-collab/issues)
